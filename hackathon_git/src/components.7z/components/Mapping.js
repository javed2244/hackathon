// eslint-disable-next-line
import React, { Component } from 'react';

class Mapping extends React.Component {
   render() {
      return (
         <div className="Mapping">
            <h2>IP-SGT-SGACL</h2>
            <p>Here is the IP-SGT-SGACL mapping to be done</p>
         </div>
      );
   }
}

export default Mapping;
