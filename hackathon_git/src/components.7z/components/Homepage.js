// eslint-disable-next-line
import React, { Component } from 'react';

class HomePage extends React.Component {
   render() {
      return (
         <div className="HomePage">
            <p>Welcome to HomePage of Trustsec.</p>
         </div>
      );
   }
}

export default HomePage;
