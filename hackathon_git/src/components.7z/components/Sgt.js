// eslint-disable-next-line
import React, { Component } from 'react';
import axios from 'axios';

class Sgt extends React.Component {

  constructor(props) {
     super(props);
     this.state = {
       sgtName: "Name",
       sgtTag:  "1",
       loading: false,
       message:""
     };

     this.handleInputChange = this.handleInputChange.bind(this);
     this.handleSubmit = this.handleSubmit.bind(this);
   }

   handleInputChange(event) {
       const target = event.target;
       const value = target.value;
       const name = target.name;

       this.setState({ [name]: value });
     }


     handleSubmit(event) {
     event.preventDefault();

      //  const data = this.state;
      const name = this.state.sgtName;
      const tag = this.state.sgtTag;
      if(!this.state.sgtName || !this.state.sgtTag){
      alert('Enter all the fields.Retry!');
      return;
    }
    this.setState({
      loading:true
    })
        //alert('Data submitted: '+ this.state.sgtName + " , " + this.state.sgtTag);
        const data ={
          name,
          tag
        }

        axios.post('/t/e01x0-1550811099/post',data)
        .then(response =>{
          console.log(response);
          this.setState({
            loading:false,
            message:response.data
          })
        })
        .catch(err =>{
          console.log(err);
          this.setState({
            loading:false
          })
        })
     }

loadOrShowMsg(){
  if(this.state.loading){
    return <p>Loding...</p>
  }else {
    return<p>{this.state.message}</p>
  }
}



   render() {
      return (
         <form onSubmit={this.handleSubmit}>
            <h2>SGT</h2>
            <p>This is SGT Page.Here inputs will be Tag name.</p>

            <br></br>
            <br></br>

            <label>
            Name:
              <input
              name="sgtName"
              type="string"
              value={this.state.sgtName}
              onChange={this.handleInputChange} />
              <br></br>
              <br></br>
              <br></br>

            Tag Value:
              <input
              name="sgtTag"
              type="number"
              value={this.state.sgtTag}
              onChange={this.handleInputChange} />
            </label>
            <br></br>
            <br></br>
            <br></br>


            <input type="Submit" value="Submit" />
            {this.loadOrShowMsg()}
          </form>

      );
   }
}

export default Sgt;
