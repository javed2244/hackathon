// eslint-disable-next-line
import React, { Component } from 'react';

class Sgacl extends React.Component {

  constructor(props) {
     super(props);
     this.state = {
       sgaclName: "",
       sgaclContent:  "permit any any"
     };

     this.handleInputChange = this.handleInputChange.bind(this);
     this.handleSubmit = this.handleSubmit.bind(this);
   }

   handleInputChange(event) {
       const target = event.target;
       const value = target.value;
       const name = target.name;

       this.setState({
         [name]: value
       });
     }


     handleSubmit(event) {
       if(!this.state.sgaclName || !this.state.sgaclContent){
       alert('Enter all the fields.Retry!');
       return;
     }
         alert('SGACL data submitted: '+this.state.sgaclName + " , " +this.state.sgaclContent );

         event.preventDefault();
     }


   render() {
      return (
          <form onSubmit={this.handleSubmit}>
            <h2>SGACL</h2>
            <p>This is SGACL Page.Here inputs will be name and ACL content.</p>
<br></br>
<br></br>
            <label>
            Name:
              <input
              name="sgaclName"
              type="string"
              value={this.state.sgaclName}
              onChange={this.handleInputChange} />
              <br></br>
              <br></br>
              <br></br>
            SGACL Content:
            <br></br>
            <br></br>
            <textarea
            name ="sgaclContent"
            rows="10" cols="50"
            value={this.state.sgaclContent}
            onChange={this.handleInputChange}>
              </textarea>


            </label>
<br></br>
<br></br>
            <input type="Submit" value="Push" />
            </form>

      );
   }
}

export default Sgacl;
